import { useMemo, useState } from "react";
import type { CalcResult } from "@shared/schema";
import { SiteFactorsCard } from "@/components/site-factors-card";
import { SpeciesCard } from "@/components/species-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, ChevronDown, ChevronUp } from "lucide-react";

interface ResultsDisplayProps {
  result: CalcResult;
  onNewSearch: () => void;
}

function fmt(n: number, dp = 0) {
  return n.toLocaleString(undefined, {
    maximumFractionDigits: dp,
    minimumFractionDigits: dp,
  });
}

export function ResultsDisplay({ result, onNewSearch }: ResultsDisplayProps) {
  const [showHow, setShowHow] = useState(false);
  const [showBreakdown, setShowBreakdown] = useState(false);
  const [q, setQ] = useState("");

  const topSpeciesCards = useMemo(() => {
    // SpeciesCard expects the legacy SpeciesResult shape.
    // We can reuse it by matching keys we already have in breakdown.
    const topKeys = new Set(result.top_recommendations.map((r) => r.code));
    const rows = result.species_breakdown
      .filter((r) => topKeys.has(r.code))
      .slice(0, 3)
      .map((r) => ({
        name: r.display_name,
        scientificName: r.scientific_name,
        code: r.code,
        suitabilityScore: r.suitability,
        suitabilityLabel:
          r.suitability >= 0.8
            ? "Very Suitable"
            : r.suitability >= 0.6
              ? "Suitable"
              : r.suitability >= 0.4
                ? "Moderate"
                : r.suitability >= 0.2
                  ? "Marginal"
                  : "Unsuitable",
        yieldClass: r.yield_class,
        cubicMetresPerHaYear: r.yield_class,
        kwhPerHaYear: r.kwh_per_ha_year,
        limitingFactors: r.zero_reason ? [r.zero_reason] : [],
        notes: "",
      }));
    return rows;
  }, [result]);

  const filteredBreakdown = useMemo(() => {
    const query = q.trim().toLowerCase();
    const rows = result.species_breakdown;
    const out = query
      ? rows.filter(
          (r) =>
            r.display_name.toLowerCase().includes(query) ||
            r.code.toLowerCase().includes(query),
        )
      : rows;
    return out;
  }, [q, result.species_breakdown]);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 flex-wrap">
        <Button variant="ghost" size="sm" onClick={onNewSearch}>
          <ArrowLeft className="h-4 w-4 mr-1" />
          New search
        </Button>
        <div className="flex-1" />
        <p className="text-sm text-muted-foreground">
          Results for{" "}
          <span className="font-medium text-foreground">
            {result.inputs.postcode}
          </span>
          {" "}
          • {fmt(result.inputs.area_ha, 2)} ha
        </p>
      </div>

      {/* Primary outputs (clean, uncluttered) */}
      <Card>
        <CardContent className="pt-5 pb-5">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Expected kWh/year</p>
              <p className="text-xl font-semibold">{fmt(result.outputs.kwh_per_year)}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Expected dry tonnes/year</p>
              <p className="text-xl font-semibold">
                {fmt(result.outputs.dry_tonnes_per_year, 1)}
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Expected oil replacement</p>
              <p className="text-xl font-semibold">
                ~{fmt(result.outputs.oil_litres_per_year)} L/year
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">#1 planting density</p>
              <p className="text-xl font-semibold">
                {fmt(result.top_recommendations?.[0]?.stems_per_ha ?? 0)}
                <span className="text-sm font-normal text-muted-foreground"> /ha</span>
              </p>
              <p className="text-xs text-muted-foreground">
                {result.top_recommendations?.[0]?.spacing_m
                  ? `${fmt(result.top_recommendations[0].spacing_m, 2)}m spacing`
                  : ""}
              </p>
            </div>
          </div>

          <div className="pt-4 flex flex-col sm:flex-row gap-3 sm:items-center">
            <Button
              variant="link"
              className="px-0"
              onClick={() => setShowHow((v) => !v)}
            >
              {showHow ? (
                <ChevronUp className="h-4 w-4 mr-1" />
              ) : (
                <ChevronDown className="h-4 w-4 mr-1" />
              )}
              How these numbers were calculated
            </Button>

            <Button
              variant="link"
              className="px-0"
              onClick={() => setShowBreakdown((v) => !v)}
            >
              {showBreakdown ? (
                <ChevronUp className="h-4 w-4 mr-1" />
              ) : (
                <ChevronDown className="h-4 w-4 mr-1" />
              )}
              Show suitability breakdown (all species)
            </Button>
          </div>

          {showHow && (
            <div className="mt-3 rounded-md border bg-muted/30 p-4">
              <ul className="list-disc pl-5 space-y-1 text-sm text-muted-foreground">
                {result.assumptions.map((a, idx) => (
                  <li key={idx}>{a}</li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>

      <SiteFactorsCard factors={result.siteFactors} />

      <div className="space-y-3">
        <div className="flex items-center gap-2 flex-wrap">
          <h3 className="text-lg font-semibold tracking-tight">Top recommendations</h3>
        </div>
        <div className="grid grid-cols-1 gap-3">
          {topSpeciesCards.map((sp, i) => (
            <SpeciesCard key={sp.code} species={sp as any} rank={i + 1} />
          ))}
        </div>
      </div>

      {showBreakdown && (
        <Card>
          <CardContent className="pt-5 pb-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
              <div className="flex-1">
                <h3 className="text-lg font-semibold tracking-tight">All species</h3>
                <p className="text-xs text-muted-foreground">
                  Full transparency: includes unsuitable species (0 means 0).
                </p>
              </div>
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search species…"
                className="sm:max-w-xs"
              />
            </div>

            <div className="overflow-x-auto">
              <table className="w-full min-w-[860px] text-sm">
                <thead>
                  <tr className="text-left border-b">
                    <th className="py-2 pr-3">Species</th>
                    <th className="py-2 pr-3">Overall</th>
                    <th className="py-2 pr-3">Suitability</th>
                    <th className="py-2 pr-3">Yield</th>
                    <th className="py-2 pr-3">Spacing</th>
                    <th className="py-2 pr-3">Stems/ha</th>
                    <th className="py-2 pr-3">Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredBreakdown.map((r) => (
                    <tr
                      key={r.species_key}
                      className={`border-b ${r.overall_score === 0 ? "opacity-60" : ""}`}
                    >
                      <td className="py-2 pr-3 font-medium">{r.display_name}</td>
                      <td className="py-2 pr-3">{fmt(r.overall_score, 1)}</td>
                      <td className="py-2 pr-3">{fmt(r.suitability * 100, 0)}%</td>
                      <td className="py-2 pr-3">YC {r.yield_class}</td>
                      <td className="py-2 pr-3">{fmt(r.spacing_m, 2)}m</td>
                      <td className="py-2 pr-3">{fmt(r.stems_per_ha)}</td>
                      <td className="py-2 pr-3 text-muted-foreground">
                        {r.zero_reason ?? ""}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <p className="text-xs text-muted-foreground">
              Showing {filteredBreakdown.length} species
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
