import type { SpeciesResult } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Zap, TreePine, TrendingUp } from "lucide-react";

interface SpeciesCardProps {
  species: SpeciesResult;
  rank: number;
}

function getSuitabilityVariant(label: string): "default" | "secondary" | "destructive" | "outline" {
  switch (label) {
    case "Very Suitable":
    case "Suitable":
      return "default";
    case "Moderate":
      return "secondary";
    case "Marginal":
    case "Unsuitable":
      return "destructive";
    default:
      return "outline";
  }
}

function formatNumber(n: number): string {
  return n >= 1000 ? `${(n / 1000).toFixed(1)}k` : n.toFixed(1);
}

export function SpeciesCard({ species, rank }: SpeciesCardProps) {
  return (
    <Card
      className="hover-elevate"
      data-testid={`card-species-${species.code}`}
    >
      <CardContent className="pt-4 pb-4">
        <div className="flex flex-col sm:flex-row sm:items-start gap-4">
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <div className="flex-shrink-0 w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center text-sm font-semibold text-primary" data-testid={`text-rank-${species.code}`}>
              {rank}
            </div>
            <div className="min-w-0 flex-1 space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className="font-semibold text-sm" data-testid={`text-species-name-${species.code}`}>
                  {species.name}
                </h4>
                <span className="text-xs text-muted-foreground italic" data-testid={`text-scientific-name-${species.code}`}>
                  {species.scientificName}
                </span>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <Badge
                  variant={getSuitabilityVariant(species.suitabilityLabel)}
                  data-testid={`badge-suitability-${species.code}`}
                >
                  {species.suitabilityLabel} ({(species.suitabilityScore * 100).toFixed(0)}%)
                </Badge>
              </div>
              {species.limitingFactors.length > 0 && (
                <div className="flex items-start gap-1.5 pt-1">
                  <AlertTriangle className="h-3 w-3 text-amber-500 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-muted-foreground" data-testid={`text-limiting-${species.code}`}>
                    {species.limitingFactors.join(", ")}
                  </p>
                </div>
              )}
              {species.notes && (
                <p className="text-xs text-muted-foreground pt-0.5" data-testid={`text-notes-${species.code}`}>{species.notes}</p>
              )}
            </div>
          </div>

          <div className="flex sm:flex-col items-center sm:items-end gap-3 sm:gap-1.5 flex-shrink-0 text-right">
            <div className="flex items-center gap-1.5">
              <TreePine className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">YC</span>
              <span className="text-sm font-semibold" data-testid={`text-yc-${species.code}`}>
                {species.yieldClass}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <TrendingUp className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">m&#179;/ha/yr</span>
              <span className="text-sm font-semibold" data-testid={`text-volume-${species.code}`}>
                {species.cubicMetresPerHaYear.toFixed(1)}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <Zap className="h-3.5 w-3.5 text-amber-500" />
              <span className="text-xs text-muted-foreground">kWh/ha/yr</span>
              <span className="text-sm font-semibold text-primary" data-testid={`text-kwh-${species.code}`}>
                {formatNumber(species.kwhPerHaYear)}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
