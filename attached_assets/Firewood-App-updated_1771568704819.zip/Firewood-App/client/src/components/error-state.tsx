import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, RotateCcw } from "lucide-react";

interface ErrorStateProps {
  message: string;
  onRetry: () => void;
}

export function ErrorState({ message, onRetry }: ErrorStateProps) {
  const friendlyMessage = message.includes("404")
    ? "That postcode wasn\u2019t found. Please check and try again."
    : message.includes("400")
      ? "Invalid postcode format. Please enter a valid UK postcode."
      : "Something went wrong while looking up that postcode. Please try again.";

  return (
    <div className="max-w-md mx-auto" data-testid="error-state">
      <Card>
        <CardContent className="pt-6 text-center space-y-4">
          <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
          <div className="space-y-1">
            <p className="text-sm font-medium">Lookup failed</p>
            <p className="text-sm text-muted-foreground">{friendlyMessage}</p>
          </div>
          <Button variant="outline" onClick={onRetry} data-testid="button-retry">
            <RotateCcw className="h-4 w-4 mr-2" />
            Try again
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
