import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { PostcodeForm } from "@/components/postcode-form";
import { ResultsDisplay } from "@/components/results-display";
import { LoadingState } from "@/components/loading-state";
import { ErrorState } from "@/components/error-state";
import type { CalcResult } from "@shared/schema";
import { TreePine, Flame } from "lucide-react";

export default function Home() {
  const [result, setResult] = useState<CalcResult | null>(null);

  const mutation = useMutation({
    mutationFn: async (payload: { postcode: string; area_ha: number }) => {
      const res = await apiRequest("POST", "/api/calc", payload);
      return (await res.json()) as CalcResult;
    },
    onSuccess: (data) => {
      setResult(data);
    },
  });

  const handleSearch = (postcode: string, areaHa: number) => {
    setResult(null);
    mutation.mutate({ postcode, area_ha: areaHa });
  };

  const handleReset = () => {
    setResult(null);
    mutation.reset();
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-primary/10 rounded-md">
              <Flame className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-semibold tracking-tight" data-testid="text-app-title">
                Firewood App
              </h1>
              <p className="text-xs text-muted-foreground">UK Species Suitability</p>
            </div>
          </div>
          <div className="ml-auto flex items-center gap-1.5 text-xs text-muted-foreground">
            <TreePine className="h-3.5 w-3.5" />
            <span>FR ESC V4 data</span>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {!result && !mutation.isPending && !mutation.isError && (
          <div className="space-y-8">
            <div className="text-center space-y-3">
              <h2 className="text-2xl font-semibold tracking-tight">
                Plan your firewood for energy independence
              </h2>
              <p className="text-muted-foreground max-w-lg mx-auto">
                Enter a UK postcode and your land area. We’ll estimate which species will
                maximise firewood yield on your site — and what that means in real-world energy.
              </p>
            </div>
            <PostcodeForm onSubmit={handleSearch} isLoading={false} />

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              {[
                {
                  title: "Site Analysis",
                  desc: "Climate, soil & topographic data from the Forest Research national datasets",
                },
                {
                  title: "Species Ranking",
                  desc: "Broadleaf species ranked by suitability from the FR ESC V4 model",
                },
                {
                  title: "Expected Replacement",
                  desc: "Expected kWh, dry tonnes, and heating-oil equivalent for your land area",
                },
              ].map((item) => (
                <div
                  key={item.title}
                  className="p-4 rounded-md bg-card border border-card-border text-center space-y-1.5"
                >
                  <p className="text-sm font-medium">{item.title}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {mutation.isPending && <LoadingState />}

        {mutation.isError && !result && (
          <ErrorState
            message={mutation.error?.message || "Something went wrong"}
            onRetry={handleReset}
          />
        )}

        {result && (
          <ResultsDisplay result={result} onNewSearch={handleReset} />
        )}
      </main>

      <footer className="border-t mt-12">
        <div className="max-w-4xl mx-auto px-4 py-6 text-center">
          <p className="text-xs text-muted-foreground">
            Data from Forest Research Ecological Site Classification (ESC V4) via frgeospatial.uk.
            Results should not replace professional forestry advice.
          </p>
        </div>
      </footer>
    </div>
  );
}
