# Firewood App (UK)

## Overview
A web application that helps users find the best firewood tree species for their UK land. Users enter a UK postcode, and the app analyses ecological site factors (climate, soil, exposure) using the real Forest Research ESC API to recommend suitable firewood species with yield and energy estimates.

## Architecture
- **Frontend**: React + Vite + TanStack Query + wouter routing + shadcn/ui components
- **Backend**: Express.js with ESC engine calling real Forest Research APIs
- **External APIs**:
  - postcodes.io (free, no auth) for UK postcode geocoding + coordinate conversion
  - Forest Research Geospatial API (frgeospatial.uk/api) for soil, topographic, climate, and ESC V4 model data
- **No database** - stateless analysis tool, results logged to server console

## Key Files
- `shared/schema.ts` - TypeScript types and Zod validation for PostcodeInput, SiteFactors, SpeciesResult, ESCResult
- `server/esc-engine.ts` - ESC engine integrating with FR API (soil extract, topographic extract, climate extract, ESC V4 model)
- `server/routes.ts` - POST /api/lookup endpoint
- `client/src/pages/home.tsx` - Main page with form and results display
- `client/src/components/` - PostcodeForm, ResultsDisplay, SiteFactorsCard, SpeciesCard, LoadingState, ErrorState

## API Endpoints
- `POST /api/lookup` - Body: `{ postcode: string }` - Returns ESCResult with site factors and ranked species

## FR API Integration Flow
1. postcodes.io: postcode → lat/lng → eastings/northings (EPSG:27700)
2. FR soil extract → SMR (soil moisture regime), SNR (soil nutrient regime)
3. FR topographic extract → elevation, slope, aspect, DAMS (wind exposure)
4. FR climate extract → AT (accumulated temperature), MD (moisture deficit), CT (continentality)
5. FR ESC V4 model → species suitability scores, yield classes, limiting factors

## Species Covered (35 broadleaf from ESC V4)
All broadleaf species returned by the FR ESC V4 model, including:
Ash, Aspen, Beech, Bigleaf Maple, Black Poplar, Black Walnut, Cider Gum, Common Alder, Common Walnut, Downy Birch, English Oak, Grey Alder, Holly, Hornbeam, Hybrid Aspen, Italian Alder, Norway Maple, Rauli, Red Alder, Red Oak, Roble, Rowan, Sessile Oak, Shining Gum, Short Rotation Coppice, Short Rotation Forestry, Silver Birch, Small-leaved Lime, Sweet Chestnut, Sycamore, True Service Tree, White Willow, Wild Cherry, Wild Service Tree, Wych Elm

## Site Factors Displayed
- AT (accumulated temperature, day-degrees), MD (moisture deficit, mm), CT (continentality)
- DAMS (wind exposure), Elevation (m), Slope (degrees), Aspect (compass direction)
- SMR (soil moisture regime), SNR (soil nutrient regime), Region
