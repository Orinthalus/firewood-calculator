import type { Express } from "express";
import { createServer, type Server } from "http";
import { lookupPostcode, analyseLocation, analyseLocationCalc } from "./esc-engine";
import { postcodeSchema, calcSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // New MVP endpoint: postcode + land area -> energy plan
  app.post("/api/calc", async (req, res) => {
    try {
      const parsed = calcSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({
          error: "Invalid input",
          details: parsed.error.flatten().fieldErrors,
        });
        return;
      }

      const { postcode, area_ha } = parsed.data;
      console.log(`[Firewood App] Calculating plan for: ${postcode} (${area_ha} ha)`);

      const location = await lookupPostcode(postcode);
      const result = await analyseLocationCalc(
        postcode,
        area_ha,
        location.lat,
        location.lng,
        location.eastings,
        location.northings,
        location.region,
      );

      res.json(result);
    } catch (error: any) {
      console.error(`[Firewood App] Error:`, error.message);
      const status = error.message?.includes("404") ? 404 : 500;
      res.status(status).json({ error: error.message });
    }
  });

  // Legacy endpoint (kept for now): postcode -> site factors + top species
  app.post("/api/lookup", async (req, res) => {
    try {
      const parsed = postcodeSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({
          error: "Invalid postcode",
          details: parsed.error.flatten().fieldErrors,
        });
        return;
      }

      const { postcode } = parsed.data;
      console.log(`[Firewood App] Looking up postcode: ${postcode}`);

      const location = await lookupPostcode(postcode);
      console.log(`[Firewood App] Location found:`, {
        lat: location.lat,
        lng: location.lng,
        eastings: location.eastings,
        northings: location.northings,
        region: location.region,
      });

      const result = await analyseLocation(
        postcode,
        location.lat,
        location.lng,
        location.eastings,
        location.northings,
        location.region
      );

      console.log(`[Firewood App] Site factors:`, {
        AT5: result.siteFactors.accumulatedTemperature,
        MD: result.siteFactors.moistureDeficit,
        CT: result.siteFactors.continentality,
        DAMS: result.siteFactors.windExposure,
        SMR: result.siteFactors.soilMoistureRegime,
        SNR: result.siteFactors.soilNutrientRegime,
        Altitude: result.siteFactors.estimatedAltitude,
      });

      console.log(
        `[Firewood App] Top species (${result.species.length} total):`,
        result.species.slice(0, 5).map((s) => ({
          name: s.name,
          code: s.code,
          suitability: `${s.suitabilityLabel} (${s.suitabilityScore})`,
          yieldClass: s.yieldClass,
          kwhPerHaYear: s.kwhPerHaYear,
          limitingFactor: s.limitingFactors[0] || "none",
        }))
      );

      res.json(result);
    } catch (error: any) {
      console.error(`[Firewood App] Error:`, error.message);
      const status = error.message?.includes("404") ? 404 : 500;
      res.status(status).json({ error: error.message });
    }
  });

  return httpServer;
}
